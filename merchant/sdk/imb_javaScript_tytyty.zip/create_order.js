// Create a unique order ID
const orderId = Math.floor(Math.random() * (999999999 - 123456789 + 1)) + 123456789;
const token = '542a08bc000ceb2570dca59993610565'; // Replace with your API token
const url = 'https://pay.imb.org.in/api/create-order';

const data = {
    customer_mobile: '1234567890',
    user_token: token,
    amount: '2',
    order_id: orderId,
    redirect_url: 'https://your_Redirect_URL.in/',
    remark1: 'Customer-email@gmail.com',
    remark2: 'Additional data here'
};

// Send POST request
fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(data)
})
.then(response => response.json())
.then(jsonResponse => {
    if (jsonResponse && jsonResponse.result) {
        const paymentUrl = jsonResponse.result.payment_url;
        console.log(`Redirecting to Payment URL: ${paymentUrl}`);
        // Redirect to payment URL (in a browser environment)
        window.location.href = paymentUrl;
    } else {
        console.error("Error in response data:", jsonResponse);
    }
})
.catch(error => console.error("Failed to create order:", error));
