const api_url = "https://pay.imb.org.in/api/check-order-status";
const user_token = "2048f66bef68633fa3262d7a398ab577";  // Replace with your API token
const order_id = "9876543210";  // Replace with the actual order ID

const postData = new URLSearchParams({
    user_token: user_token,
    order_id: order_id
});

// Send POST request to check status
fetch(api_url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: postData
})
.then(response => response.json())
.then(responseData => {
    if (responseData.status === "COMPLETED") {
        const result = responseData.result;
        console.log("Transaction Status:", result.txnStatus);
        console.log("Message:", responseData.message);
        console.log("Order ID:", result.orderId);
        console.log("Amount:", result.amount);
        console.log("Date:", result.date);
        console.log("UTR:", result.utr);
    } else {
        console.error("Error:", responseData.message);
    }
})
.catch(error => console.error("Failed to check order status:", error));
