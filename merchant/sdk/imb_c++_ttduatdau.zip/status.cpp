#include <iostream>
#include <string>
#include <curl/curl.h>

int main() {
    std::string api_url = "https://pay.imb.org.in/api/check-order-status";
    std::string user_token = "2048f66bef68633fa3262d7a398ab577";  // Replace with your API token
    std::string order_id = "9876543210";  // Replace with the actual order ID
    
    std::string post_data = "user_token=" + user_token + "&order_id=" + order_id;
    
    CURL *curl;
    CURLcode res;
    
    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, api_url.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data.c_str());
        
        res = curl_easy_perform(curl);
        
        if (res != CURLE_OK)
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        
        curl_easy_cleanup(curl);
    }
    
    return 0;
}
