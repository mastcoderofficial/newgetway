#include <iostream>
#include <string>
#include <curl/curl.h>
#include <cstdlib>
#include <ctime>

int main() {
    srand(time(0));
    int orderId = rand() % (999999999 - 123456789 + 1) + 123456789;
    std::string token = "542a08bc000ceb2570dca59993610565";  // Replace with your API token
    std::string url = "https://pay.imb.org.in/api/create-order";
    
    std::string data = "customer_mobile=1234567890&user_token=" + token + "&amount=2&order_id=" + std::to_string(orderId) +
                       "&redirect_url=https://your_Redirect_URL.in/&remark1=Customer-email@gmail.com&remark2=Additional data here";

    CURL *curl;
    CURLcode res;
    
    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data.c_str());
        
        res = curl_easy_perform(curl);
        
        if (res != CURLE_OK)
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
        
        curl_easy_cleanup(curl);
    }
    
    return 0;
}
