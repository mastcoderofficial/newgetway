import requests
import random

# URL for creating an order
url = 'https://pay.imb.org.in/api/create-order'
order_id = random.randint(123456789, 999999999)  # Generate a unique order ID
token = '542a08bc000ceb2570dca59993610565'  # Replace with your API token

# Data for the POST request
data = {
    'customer_mobile': '1234567890',  # Customer's phone number
    'user_token': token,
    'amount': '2',
    'order_id': order_id,
    'redirect_url': 'https://your_Redirect_URL.in/',
    'remark1': 'Customer-email@gmail.com',
    'remark2': 'Additional data here'
}

# Sending POST request
response = requests.post(url, data=data)

# Check if the request was successful
if response.status_code == 200:
    json_response = response.json()
    
    if json_response and 'result' in json_response:
        payment_url = json_response['result']['payment_url']
        print(f"Redirecting to Payment URL: {payment_url}")
    else:
        print("Error in response data:", json_response)
else:
    print("Failed to create order:", response.text)
