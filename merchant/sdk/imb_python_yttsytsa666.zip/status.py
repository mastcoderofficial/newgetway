import requests

# API endpoint and token
api_url = "https://pay.imb.org.in/api/check-order-status"
user_token = "2048f66bef68633fa3262d7a398ab577"  # Replace with your API token
order_id = "9876543210"  # Replace with the actual order ID

# Data for POST request
post_data = {
    'user_token': user_token,
    'order_id': order_id
}

# Sending POST request
response = requests.post(api_url, data=post_data)

# Process response
if response.status_code == 200:
    response_data = response.json()
    
    if response_data['status'] == "COMPLETED":
        result = response_data['result']
        print("Transaction Status:", result['txnStatus'])
        print("Message:", response_data['message'])
        print("Order ID:", result['orderId'])
        print("Amount:", result['amount'])
        print("Date:", result['date'])
        print("UTR:", result['utr'])
    else:
        print("Error:", response_data['message'])
else:
    print("Failed to check order status:", response.text)
