=== imb UPI Payment Gateway Plugin ===
Contributors: Pankaj Sah
Donate link: https://pay.imb.org.in/
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Get Payment on your own Imb Payment Gateway without any Transaction charges, Just a simple Subscriptions.

== Installation ==

1. Goto WordPress Admin > Plugins > Add New > Upload the plugin zip file.

== Frequently Asked Questions ==

Q. Is there any transaction fees on each transaction?
Ans. No transaction fees.